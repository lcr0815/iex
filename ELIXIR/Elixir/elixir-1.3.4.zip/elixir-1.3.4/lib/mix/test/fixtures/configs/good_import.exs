use Mix.Config
import_config "good_config.exs"
:done
