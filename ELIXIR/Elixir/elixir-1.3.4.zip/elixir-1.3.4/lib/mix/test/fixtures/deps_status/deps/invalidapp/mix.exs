defmodule InvalidApp.Mixfile do
  use Mix.Project

  def project do
    [app: :invalidapp,
     version: "1.0"]
  end
end
