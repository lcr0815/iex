use Mix.Config

config :escripttest, erlval: "Erlang value"
