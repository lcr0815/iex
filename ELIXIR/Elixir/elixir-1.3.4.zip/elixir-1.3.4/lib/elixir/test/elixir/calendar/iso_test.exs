Code.require_file "../test_helper.exs", __DIR__

defmodule Calendar.ISOTest do
  use ExUnit.Case, async: true
  doctest Calendar.ISO
end
