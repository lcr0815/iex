use Mix.Config
config :app, Repo, key: [nested: true]
