defmodule WarningsSample do
  def hello(a), do: a
  def hello(b), do: b
end
