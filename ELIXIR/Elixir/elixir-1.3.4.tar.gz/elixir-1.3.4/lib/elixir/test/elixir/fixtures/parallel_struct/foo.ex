defmodule Foo do
  defstruct name: ""
  def bar?(%Bar{}), do: true
end
