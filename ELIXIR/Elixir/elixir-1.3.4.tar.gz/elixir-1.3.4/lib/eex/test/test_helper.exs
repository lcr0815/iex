ExUnit.start [trace: "--trace" in System.argv]
